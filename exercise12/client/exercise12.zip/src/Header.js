import "./Header.css";



function Header() {
  return (
    <>
      <header className="header">
        <h2>
            Kiki The Cats Favorite Things
        </h2>
      </header>
    </>
  );
}

export default Header;