const MAIN_DATA = [
    { content: 
    <>
        <article>
            <h1>Boxes</h1>
            <p>After much research. Top scientists have discovered that Kiki's favorite boxes are those that originally caried expensive merchandise.</p>
            <p>With an even greater preference for the box when the expensive merchandise was purchased specifically for him to play with. </p>
            <p>He will show complete apathy for the expensive item and put all his focus on the box.</p>
        </article>
</>  },
    { content: 
      <>
        <article>
            <h1>Feather Wands</h1>
            <p>His nickname is "Murder Mittens". His nickname becomes immediately obvious when a feather wand is nearby. </p>
            <p>He enters a state many would refer to as Murder Mode where he will stalk and pounce on the feather wand. </p>
            <p>Many studies have been done and 9/10 scientists agree that it is "adorable". The other 1/10 were self described dog people.</p>
        </article>
      </>},
    { content: 
      <>
        <article>
            <h1>Fancy Bandana Collars</h1>
            <p>It's unclear whether or not he actually likes the fancy bandana collars. If anything he probably just tolerates them.</p>
            <p>Most people would agree though. He looks really good while wearing them. </p>
        </article>
      </>},
  ];
  
  export { MAIN_DATA };