import "./Footer.css";

function Footer() {
    return (
<>
    <div className="footer">
    <p>Jacques 'Jack' Zwielich</p>
</div>
</> 
    )
  
}

export default Footer;
