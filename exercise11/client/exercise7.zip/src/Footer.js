import "./Footer.css";

function Footer() {
    return (
<>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1"></meta>
    </head>

    <div className="footer">
    <p>©Jacques Zwielich 2022</p>
</div>
</> 
    )
  
}

export default Footer;
