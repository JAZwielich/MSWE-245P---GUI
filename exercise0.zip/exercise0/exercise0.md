<!DOCTYPE html>
<html class="scripts-not-loaded" dir="ltr"   lang="en">
<head>
  <meta charset="utf-8">
  <meta name="sentry-trace" content="770866e678ea4304bec6346a95697f89-c1451a889f324842-0"/>
  <link rel="preload" href="https://du11hjcvx0uqb.cloudfront.net/dist/fonts/lato/extended/Lato-Regular-bd03a2cc27.woff2" as="font" type="font/woff2" crossorigin="anonmyous">
  <link rel="preload" href="https://du11hjcvx0uqb.cloudfront.net/dist/fonts/lato/extended/Lato-Bold-cccb897485.woff2" as="font" type="font/woff2" crossorigin="anonmyous">
  <link rel="preload" href="https://du11hjcvx0uqb.cloudfront.net/dist/fonts/lato/extended/Lato-Italic-4eb103b4d1.woff2" as="font" type="font/woff2" crossorigin="anonmyous">
  <link rel="stylesheet" media="screen" href="https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/no_variables/bundles/fonts-43e9c545fc.css" />
    <script>if (navigator.userAgent.match(/(MSIE|Trident\/)/)) location.replace('/ie-is-not-supported.html')</script>
  
  <link rel="shortcut icon" type="image/x-icon" href="https://du11hjcvx0uqb.cloudfront.net/dist/images/favicon-e10d657a73.ico" />
  <link rel="apple-touch-icon" href="https://du11hjcvx0uqb.cloudfront.net/dist/images/apple-touch-icon-585e5d997d.png" />
  <link rel="stylesheet" media="all" href="https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/372ae789d3da181f64208364be731239/variables-7dd4b80918af0e0218ec0229e4bd5873.css" />
  <link rel="stylesheet" media="all" href="https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/new_styles_normal_contrast/bundles/common-5a50100f64.css" />
  <meta name="apple-itunes-app" content="app-id=480883488">
<link rel="manifest" href="/web-app-manifest/manifest.json">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#0064a4">
  <meta name="robots" content="noindex,nofollow" />
  <link rel="stylesheet" media="all" href="https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/new_styles_normal_contrast/bundles/assignments-81a86619c8.css" />
<link rel="stylesheet" media="all" href="https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/new_styles_normal_contrast/bundles/tinymce-59c32fac15.css" />
<link rel="stylesheet" media="all" href="https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/new_styles_normal_contrast/bundles/learning_outcomes-a9a9fe5d8b.css" />
  <link rel="stylesheet" media="all" href="https://instructure-uploads.s3.amazonaws.com/account_44070000000000001/attachments/19068469/canvas.css" />
  <script>
    function _earlyClick(e){
      var c = e.target
      while (c && c.ownerDocument) {
        if (c.getAttribute('href') == '#' || c.getAttribute('data-method')) {
          if (!e.defaultPrevented) {
            e.preventDefault()
          }
          (_earlyClick.clicks = _earlyClick.clicks || []).push(c)
          break
        }
        c = c.parentNode
      }
    }
    document.addEventListener('click', _earlyClick)
  </script>


  <script>
    INST = {"environment":"production","allowMediaComments":true,"kalturaSettings":{"domain":"nv.instructuremedia.com","resource_domain":"nv.instructuremedia.com","rtmp_domain":"iad.rtmp.instructuremedia.com","partner_id":"9","subpartner_id":"0","player_ui_conf":"0","kcw_ui_conf":"0","upload_ui_conf":"0","max_file_size_bytes":534773760,"do_analytics":false,"hide_rte_button":false,"js_uploader":true},"disableGooglePreviews":true,"logPageViews":true,"editorButtons":[{"name":"Commons Favorites","id":578,"favorite":false,"url":"https://lor.instructure.com/api/lti/favorite-resources","icon_url":"https://lor.instructure.com/img/icon_commons.png","canvas_icon_class":null,"width":800,"height":400,"use_tray":true,"description":"\u003cp\u003eFind and share course content\u003c/p\u003e\n"},{"name":"Google Apps","id":1077,"favorite":false,"url":"https://google-drive-lti-iad-prod.instructure.com/lti/rce-content-selection","icon_url":"https://google-drive-lti-iad-prod.instructure.com/icon.png","canvas_icon_class":null,"width":700,"height":600,"use_tray":false,"description":"\u003cp\u003eAllows you to pull in documents from Google Drive to Canvas\u003c/p\u003e\n"},{"name":"YuJa Media 2.0","id":1228,"favorite":false,"url":"https://uci.yuja.com/LMSEntry.jsp","icon_url":"https://uci.yuja.com/Dashboard/icons/yuja_basic.png","canvas_icon_class":null,"width":800,"height":600,"use_tray":false,"description":"\u003cp\u003eYuJa is an Enterprise Video Platform.\u003c/p\u003e\n"},{"name":"Insert a Wiley Resource","id":9586,"favorite":false,"url":"https://lti.education.wiley.com/wpng/api/v1/lti/resourcediscoverytool","icon_url":"https://education.wiley.com/assets/images/wp.svg","canvas_icon_class":null,"width":1160,"height":660,"use_tray":false,"description":"\u003cp\u003eOutcomes-based learning.\u003c/p\u003e\n"}],"unsplashEnabled":true};
    ENV = {"ASSET_HOST":"https://du11hjcvx0uqb.cloudfront.net","active_brand_config_json_url":"https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/372ae789d3da181f64208364be731239/variables-7dd4b80918af0e0218ec0229e4bd5873.json","active_brand_config":{"md5":"372ae789d3da181f64208364be731239","variables":{"ic-brand-primary":"#0064a4","ic-link-color":"#0064a4","ic-brand-global-nav-bgd":"#0064a4","ic-brand-global-nav-avatar-border":"#f1c11f","ic-brand-global-nav-menu-item__badge-bgd":"#f1c11f","ic-brand-global-nav-logo-bgd":"#0064a4","ic-brand-header-image":"https://instructure-uploads.s3.amazonaws.com/account_44070000000000001/attachments/3921255/uci-canvas-pathed.svg","ic-brand-watermark-opacity":"1","ic-brand-Login-body-bgd-color":"#0064a4","ic-brand-Login-body-bgd-shadow-color":"#0064a4","ic-brand-Login-logo":"https://instructure-uploads.s3.amazonaws.com/account_44070000000000001/attachments/3921257/canvas-badge-paths.svg","ic-brand-Login-Content-bgd-color":"#0064a4","ic-brand-Login-instructure-logo":"#0064a4"},"share":false,"name":null,"created_at":"2022-05-26T08:35:37-07:00","js_overrides":"https://instructure-uploads.s3.amazonaws.com/account_44070000000000001/attachments/19068468/canvas.js","css_overrides":"https://instructure-uploads.s3.amazonaws.com/account_44070000000000001/attachments/19068469/canvas.css","parent_md5":null,"mobile_js_overrides":"https://instructure-uploads.s3.amazonaws.com/account_44070000000000001/attachments/19068470/canvas_mobile.js","mobile_css_overrides":""},"confetti_branding_enabled":false,"url_to_what_gets_loaded_inside_the_tinymce_editor_css":["https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/372ae789d3da181f64208364be731239/variables-7dd4b80918af0e0218ec0229e4bd5873.css","https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/new_styles_normal_contrast/bundles/what_gets_loaded_inside_the_tinymce_editor-a64c7fe33c.css","https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/no_variables/bundles/fonts-43e9c545fc.css"],"url_for_high_contrast_tinymce_editor_css":["https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/default/variables-high_contrast-7dd4b80918af0e0218ec0229e4bd5873.css","https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/new_styles_high_contrast/bundles/what_gets_loaded_inside_the_tinymce_editor-fa0672d544.css","https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/no_variables/bundles/fonts-43e9c545fc.css"],"current_user_id":"22413","current_user_global_id":"44070000000022413","current_user_roles":["user","student"],"current_user_is_student":true,"current_user_types":[],"current_user_disabled_inbox":false,"current_user_visited_tabs":null,"discussions_reporting":false,"files_domain":"cluster37.canvas-user-content.com","DOMAIN_ROOT_ACCOUNT_ID":"44070000000000001","k12":false,"help_link_name":"Help","help_link_icon":"help","use_high_contrast":false,"auto_show_cc":false,"disable_celebrations":false,"disable_keyboard_shortcuts":false,"LTI_LAUNCH_FRAME_ALLOWANCES":["geolocation *","microphone *","camera *","midi *","encrypted-media *","autoplay *","clipboard-write *","display-capture *"],"DEEP_LINKING_POST_MESSAGE_ORIGIN":"https://canvas.eee.uci.edu","DEEP_LINKING_LOGGING":null,"comment_library_suggestions_enabled":false,"SETTINGS":{"open_registration":false,"collapse_global_nav":true,"release_notes_badge_disabled":false,"filter_speed_grader_by_student_group":false},"FULL_STORY_ENABLED":false,"RAILS_ENVIRONMENT":"Production","SENTRY_FRONTEND":{"dsn":"https://355a1d96717e4038ac25aa852fa79a8f@relay-iad.sentry.insops.net/388","org_slug":"instructure","base_url":"https://sentry.insops.net","normalized_route":"/courses/{course_id}/assignments/{id}","errors_sample_rate":"0.0005","traces_sample_rate":"0.0005","url_deny_pattern":"instructure-uploads.*amazonaws.com","revision":"canvas-lms@20221026.114"},"API_GATEWAY_URI":"https://api.us-east-1.instructure.com/graphql/future","DATA_COLLECTION_ENDPOINT":"https://canvas-frontend-data-iad-prod.inscloudgate.net/submit","DIRECT_SHARE_ENABLED":false,"FEATURES":{"featured_help_links":true,"lti_platform_storage":false,"scale_equation_images":true,"new_equation_editor":true,"buttons_and_icons_cropper":true,"course_paces_for_sections":true,"calendar_series":false,"account_level_blackout_dates":false,"account_calendar_events":false,"rce_ux_improvements":false,"render_both_to_do_lists":false,"course_paces_redesign":false,"product_tours":false,"files_dnd":true,"usage_rights_discussion_topics":true,"granular_permissions_manage_users":true,"create_course_subaccount_picker":true,"lti_deep_linking_module_index_menu_modal":true,"lti_multiple_assignment_deep_linking":true,"buttons_and_icons_root_account":true,"extended_submission_state":false,"wrap_calendar_event_titles":true,"scheduled_page_publication":false,"embedded_release_notes":true,"canvas_k6_theme":false,"new_math_equation_handling":true},"current_user":{"id":"22413","anonymous_id":"hal","display_name":"Jacques Alfred Zwielich","avatar_image_url":"https://canvas.eee.uci.edu/images/messages/avatar-50.png","html_url":"https://canvas.eee.uci.edu/about/22413","pronouns":null,"avatar_is_fallback":true},"page_view_update_url":"/page_views/6390040a-34ad-41b5-9f3c-5a68f2234e78?page_view_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpIjoiNjM5MDA0MGEtMzRhZC00MWI1LTlmM2MtNWE2OGYyMjM0ZTc4IiwidSI6NDQwNzAwMDAwMDAwMjI0MTMsImMiOiIyMDIyLTExLTA3VDAyOjQ0OjA3LjYyWiJ9.vDNVkqwQ2OcxzK0yjdLaC3gKtVtLFSKNHBu89cdhpas","context_asset_string":"course_49897","ping_url":"https://canvas.eee.uci.edu/api/v1/courses/49897/ping","TIMEZONE":"America/Los_Angeles","CONTEXT_TIMEZONE":"America/Los_Angeles","LOCALES":["en"],"BIGEASY_LOCALE":"en_US","FULLCALENDAR_LOCALE":"en","MOMENT_LOCALE":"en","rce_auto_save_max_age_ms":86400000,"K5_USER":false,"K5_HOMEROOM_COURSE":false,"K5_SUBJECT_COURSE":false,"LOCALE_TRANSLATION_FILE":"/dist/javascripts/translations/en-888412cb6b.json","media_comment_asset_string":"user_22413","COURSE_ID":"49897","SUBMISSION_ID":"77074455","FIRST_ANNOTATION_SUBMISSION":false,"RICH_CONTENT_APP_HOST":"rich-content-iad.inscloudgate.net","JWT":"ZXlKaGJHY2lPaUprYVhJaUxDSmxibU1pT2lKQk1qVTJSME5OSWl3aWNtVm5hVzl1SWpvaWRYTXRaV0Z6ZEMweElpd2laVzUyYVhKdmJtMWxiblFpT2lKUWNtOWtkV04wYVc5dUluMC4ub3o5WXdQU01WOUJnQmN6bS5xSENVT0s4ZE9zNlZHWWE2SXpqbWw4OFRXQkRrT2p4NmpUeVdydzhNaW9GZGpDUzgydlEwc3pHQ1dsZ29EQTNZNTRuNnhJdGpoeUkxNmhNYWxPUnphaTItVEU3a0dNdzFJTXN5aUY3OGtKNE1aM2d1M3hBYjBBbmtkaERTcmhTbkFKZHNWVVRZNWFhTUxRRldkb1NxbERkUWxMUmVNMXRwakpVTkJVb3BTT3BmMlV3UGQ1c044VldsZnpsZmpnSHllU3FMU0VIZDhPLUpQYkhVUENfd0hNeWNHaXhZbVZoT2tqUUFWOTVrUXJyRW0tNnNrbGZZYjk2LUo1QmZPeUhNZ1YzY21BOUhKMG1RRVhHek9PcTk5M1dBQWpVdDJxaERkY291UEZtVmViNDYwR2xQZVE0YlpXMGdSRkQzTXNvMmh4WUE2b3lxamN2UjE2VjV1SF9zQjBxZ3dWMlJCcGZRek5GSXJnRE1DWnFpNUE4alFYN1BZTnFBS0JFMGtOWWxkekxnWkNmMWZqZzEyczUybzBRWmctUFZ0RXE3SC1mdEJEWFlpSjdCTVUyNGgtWlRnZFhwVFRCNVRid2VUT0dKaHNzOHNQTmdHbzFBc0JVOGlLdmstd0pkOHJnZGdQYWtsV3RLcHRpWTExd0FhOHJ4NElFQjdhOFVSblhnNF8xVVZHeEk2ZGc5dTQ3MDg2LXo3SGY3QXloWmxoSm4tbWJFellCYm1uQnd6SFVhNWNwXzllYnpuSVlhM25FS3l3ZXp2RkN5RXN2NzV3dXZNZmw4STZIOHpjWjd2YmNjbjBDVVFPaWQtUkktMWRFX0h6OWoyaW5zRWlWMk1nQ0twVlFPd2VLOWZUUVpsaFdlWG5VUG41b3l1M2s3ZER2cHRIVnNONnVzVlkxNlNGVGRtbnJzMWtvNUJPa0ZNekVJUnZhR0J0N3pYTGF5TlNDZFpfM0V4U3V6TWxRWjJYZEdMQllIcGVDY1lEN2tydzZ5RHp5NUx3MFlaTWloQVhySm5KN0I1VmlVc0xlaDNyY0daTGczcjhTS3ZhNjB2aGhlLXlRekwwXzhIdy56YzhLYlE0VEQyd1V1TlVLRExMT3NR","RICH_CONTENT_CAN_UPLOAD_FILES":false,"RICH_CONTENT_CAN_EDIT_FILES":false,"RICH_CONTENT_FILES_TAB_DISABLED":false,"RICH_CONTENT_INST_RECORD_TAB_DISABLED":false,"ASSIGNMENT_ID":"1038872","PREREQS":{},"EULA_URL":null,"EXTERNAL_TOOLS":[{"id":"1077","domain":"google-drive-lti-iad-prod.instructure.com","url":"https://google-drive-lti-iad-prod.instructure.com/lti/course-navigation","consumer_key":"734ad74a-324b-4922-80b7-805048ae78ca","name":"Google Apps","description":"Allows you to pull in documents from Google Drive to Canvas","created_at":"2018-04-04T16:25:51-07:00","updated_at":"2021-10-27T22:39:42-07:00","privacy_level":"name_only","custom_fields":{"account_id":"$Canvas.account.id","assignment_title":"$Canvas.assignment.title","base_url":"$Canvas.api.baseUrl","collaboration_members_url":"$Canvas.api.collaborationMembers.url","domain":"$Canvas.api.domain","group_context_ids":"$Canvas.group.contextIds","masquerading_user_id":"$Canvas.masqueradingUser.userId","membership_service_url":"$ToolProxyBinding.memberships.url","previous_context_ids":"$Canvas.course.previousContextIds","previous_context_ids_recursive":"$Canvas.course.previousContextIds.recursive","time_zone":"$Person.address.timezone","user_id":"$Canvas.user.id"},"workflow_state":"name_only","vendor_help_link":null,"account_navigation":null,"similarity_detection":null,"assignment_edit":null,"assignment_menu":null,"assignment_index_menu":null,"assignment_group_menu":null,"assignment_selection":{"enabled":true,"message_type":"ContentItemSelectionRequest","text":"Google Docs Cloud Assignment","url":"https://google-drive-lti-iad-prod.instructure.com/lti/cloud-template-selection","label":"Google Docs Cloud Assignment","selection_width":800,"selection_height":400,"icon_url":"https://google-drive-lti-iad-prod.instructure.com/icon.png"},"assignment_view":null,"collaboration":{"enabled":true,"canvas_icon_class":"icon-lti","icon_url":"https://google-drive-lti-iad-prod.instructure.com/icon.png","message_type":"ContentItemSelectionRequest","text":"Google Drive","url":"https://google-drive-lti-iad-prod.instructure.com/lti/collaboration-content-selection","label":"Google Drive","selection_width":800,"selection_height":400},"course_assignments_menu":null,"course_home_sub_navigation":null,"course_navigation":{"enabled":true,"default":"disabled","text":"Google Drive","url":"https://google-drive-lti-iad-prod.instructure.com/lti/course-navigation","label":"Google Drive","selection_width":800,"selection_height":400,"icon_url":"https://google-drive-lti-iad-prod.instructure.com/icon.png"},"course_settings_sub_navigation":null,"discussion_topic_menu":null,"discussion_topic_index_menu":null,"editor_button":{"enabled":true,"icon_url":"https://google-drive-lti-iad-prod.instructure.com/icon.png","message_type":"ContentItemSelectionRequest","selection_height":600,"selection_width":700,"url":"https://google-drive-lti-iad-prod.instructure.com/lti/rce-content-selection","label":"Google Apps"},"file_menu":null,"file_index_menu":null,"global_navigation":null,"homework_submission":{"enabled":true,"canvas_icon_class":"icon-lti","icon_url":"https://google-drive-lti-iad-prod.instructure.com/icon.png","message_type":"ContentItemSelectionRequest","text":"Google Drive","url":"https://google-drive-lti-iad-prod.instructure.com/lti/homework-content-selection","label":"Google Drive","selection_width":800,"selection_height":400},"link_selection":{"enabled":"true","message_type":"ContentItemSelectionRequest","selection_height":600,"selection_width":700,"text":"Google Drive","url":"https://google-drive-lti-iad-prod.instructure.com/lti/module-content-selection","label":"Google Drive","icon_url":"https://google-drive-lti-iad-prod.instructure.com/icon.png"},"migration_selection":null,"module_group_menu":null,"module_index_menu":null,"module_index_menu_modal":null,"module_menu":null,"module_menu_modal":null,"post_grades":null,"quiz_menu":null,"quiz_index_menu":null,"resource_selection":null,"submission_type_selection":null,"student_context_card":null,"tool_configuration":null,"user_navigation":null,"wiki_index_menu":null,"wiki_page_menu":null,"is_rce_favorite":false,"icon_url":"https://google-drive-lti-iad-prod.instructure.com/icon.png","not_selectable":false,"version":"1.1","deployment_id":"1077:7db438071375c02373713c12c73869ff2f470b68"}],"PERMISSIONS":{"context":{"read_as_admin":false,"manage_assignments":false,"manage_assignments_edit":false},"assignment":{"update":false,"submit":true},"can_manage_groups":true},"ROOT_OUTCOME_GROUP":{"id":"37572","title":"SWE 245P LAB A: GUI PROGRAMMING (37930)","vendor_guid":null,"url":"/api/v1/courses/49897/outcome_groups/37572","subgroups_url":"/api/v1/courses/49897/outcome_groups/37572/subgroups","outcomes_url":"/api/v1/courses/49897/outcome_groups/37572/outcomes","can_edit":false,"import_url":"/api/v1/courses/49897/outcome_groups/37572/import","context_id":"49897","context_type":"Course","description":null},"SIMILARITY_PLEDGE":null,"CONFETTI_ENABLED":false,"EMOJIS_ENABLED":false,"EMOJI_DENY_LIST":null,"USER_ASSET_STRING":"user_22413","CONDITIONAL_RELEASE_SERVICE_ENABLED":true,"CONDITIONAL_RELEASE_ENV":{"assignment":{"id":"1038872","title":"Exercise 0: Git 101","description":"\u003cp\u003eThis is Exercise ZERO. Pun intended. This might be nothing new for you at this point, so this is a good way to earn some extra points. If this is something new for you, awesome, we all have to start somewhere!\u003c/p\u003e\n\u003cp\u003eBefore we would start doing all sorts of magic with HTML, CSS, JavaScript, it is better if we setup a way how we can learn from our mistakes, and where we can store some knowledge for the long run.\u0026nbsp;\u003c/p\u003e\n\u003cp\u003eWe could do this in many ways, like setting up a Wiki, but I think the best way is to just simply collect all artifacts related to this class in a repository that is handled through Git and GitHub. Here is a short Wiki:\u003c/p\u003e\n\u003cp\u003e\u003cstrong\u003e\u003cem\u003eWhat's a repository? \u003c/em\u003e🧐\u003c/strong\u003e\u003c/p\u003e\n\u003cp\u003eA repository contains all of your project's files and each file's revision history. You can discuss and manage your project's work within the repository.\u003c/p\u003e\n\u003cp\u003eA repository is often just simply called, a \u003cem\u003erepo\u003c/em\u003e.\u003c/p\u003e\n\u003cp\u003e\u003cstrong\u003e\u003cem\u003eWhat is a commit? \u003c/em\u003e🧐\u003c/strong\u003e\u003c/p\u003e\n\u003cp\u003eCommitting essentially means that you add/modify/remove a file or some content of a file from your folder and you give it to Git for safe-keeping.\u0026nbsp;\u003c/p\u003e\n\u003cp\u003eThe easiest way to grasp what a commit really is: let's say you work on some complex code. You want to make sure you can review the content later. You might save it out to a note, but eh, that's not a sophisticated solution. Thus, you can just add (commit) this code to your Git. It will be remembered for you forever, with some sort of a license plate (commit hash) and with the date you committed the code.\u003c/p\u003e\n\u003cp\u003e\u003cem\u003e\u003cstrong\u003eIs Git the same thing as GitHub? \u003c/strong\u003e\u003c/em\u003e\u003cstrong\u003e🧐\u003c/strong\u003e\u003c/p\u003e\n\u003cp\u003eNoooooooooooooo. 😱 Git is a software that you download to your computer and that essentially keeps track of changes of your files in destination (local) folder. If you want to\u0026nbsp; save something you can commit so it is remembered \"forever\". Thus, you can always go back to your commits if you messed up something in your current code.\u003c/p\u003e\n\u003ch4\u003eThus, our job now is to:\u003c/h4\u003e\n\u003col\u003e\n\u003cli\u003eInstall Git.\u003c/li\u003e\n\u003cli\u003eCreate a repository.\u0026nbsp;\u003c/li\u003e\n\u003cli\u003ePrepping to commit \u0026amp; commit.\u003c/li\u003e\n\u003cli\u003eRegister a GitHub account (if you don't have one).\u003c/li\u003e\n\u003cli\u003ePush your local repository to GitHub.\u003c/li\u003e\n\u003cli\u003eShare the love to get credit for your work.\u003c/li\u003e\n\u003c/ol\u003e\n\u003ch4\u003eLet's go step-by-step\u003c/h4\u003e\n\u003cp\u003e\u003cstrong\u003e1. Install Git.\u003c/strong\u003e\u003c/p\u003e\n\u003cp\u003eYou can download the executable for macOS, Windows, and Linux/UNIX here: \u003ca href=\"https://git-scm.com/downloads\" target=\"_blank\"\u003ehttps://git-scm.com/downloads\u003c/a\u003e\u003c/p\u003e\n\u003cp\u003eNow, open your Terminal/CLI and configure Git.\u003c/p\u003e\n\u003cp\u003eFirst, you need to specify your username:\u003c/p\u003e\n\u003cpre\u003e\u003cspan\u003egit config --global user.name “replace the part within the quotes with your chosen name”\u003c/span\u003e\u003c/pre\u003e\n\u003cp\u003eThen, you need to specify your email:\u003c/p\u003e\n\u003cpre\u003e\u003cspan\u003egit config --global user.email \"replace the part within the quotes with your email address\"\u003c/span\u003e\u003c/pre\u003e\n\u003cp\u003e\u003cstrong\u003e2. Create a repository.\u003c/strong\u003e\u003c/p\u003e\n\u003cp\u003eNow, make a folder somewhere on your computer where you are going to store the code for this class. After creating this folder, add another folder where you are going to store the files of this exercise. I would probably call the folder\u003c/p\u003e\n\u003cpre\u003e245p\u003c/pre\u003e\n\u003cp\u003eand this exercise would be called\u003c/p\u003e\n\u003cpre\u003e exercise0 \u003c/pre\u003e\n\u003cp\u003eas a folder.\u0026nbsp;\u003c/p\u003e\n\u003cp\u003eThen, navigate to the 245p folder in your Terminal/CLI (if you do not know how to do this here is a short article for it: \u003ca class=\"inline_disabled\" href=\"https://learn.co/lessons/cli-essentials-bash-navigation\" target=\"_blank\"\u003eCLI Bash Navigation\u003c/a\u003e).\u003c/p\u003e\n\u003cp\u003eNow, we need to transform our 245p folder into a git folder in order for Git to be able to keep track of the changes. Thus, once you are in the folder just do:\u003c/p\u003e\n\u003cpre\u003egit init\u003c/pre\u003e\n\u003cp\u003eNow, even if you restart your computer, Git will keep track of changes in this folder. No need to initialize Git in this folder anymore.\u003c/p\u003e\n\u003cp\u003e\u003cstrong\u003e3. Prepping to commit \u0026amp; commit!\u003c/strong\u003e\u003c/p\u003e\n\u003cp\u003eYou can open now your favorite IDE, and save the content of this page (this exact description) with a file name\u003c/p\u003e\n\u003cpre\u003eexercise0.md \u003c/pre\u003e\n\u003cp\u003eOnce you are done, you can navigate back to your repo in your Terminal/CLI and tell Git with the following command to mark this file saved:\u003c/p\u003e\n\u003cpre\u003egit add exercise0/exercise0.md\u0026nbsp;\u003c/pre\u003e\n\u003cp\u003eThis command essentially marks the exercise0.md file in the exercise0 folder. Later, for the sake of simplicity you can also mark all files for saving:\u003c/p\u003e\n\u003cpre\u003egit add . \u003c/pre\u003e\n\u003cp\u003eFor later, it is also important to remember that some folders can be skipped from being remembered. So let's set that up right now! In order to do this, we need to add a file in your favorite IDE to the 245p folder. This file should be called .gitignore. In each line of this file we can add folder names, specific files that we want to skip from being remembered. Later, we certainly want to add node_modules when we are dealing with React. Remember this. 😉\u003c/p\u003e\n\u003cp\u003eAAAAAND NOOOOOOOW WE SHALL COMMIT! (This might be funny/lame based on how you read this, but hey I'm excited that I can share some knowledge with you!)\u003c/p\u003e\n\u003cp\u003eSo, we are actually saving the marked files to the local repository with the following command:\u003c/p\u003e\n\u003cpre\u003e\u003cspan\u003egit commit -m \"commit message\"\u003c/span\u003e\u003c/pre\u003e\n\u003cp\u003e\u003cspan\u003e-m means message, and you can replace the commit message between the double-quotes. The commit message should be short, preferably less than 150 characters. Always give nice commit messages. Don't be like me. Here is a good guide how to write concise commit messages (50-78 character): \u003ca class=\"inline_disabled\" href=\"http://who-t.blogspot.com/2009/12/on-commit-messages.html\" target=\"_blank\"\u003ehttp://who-t.blogspot.com/2009/12/on-commit-messages.html\u003c/a\u003e\u003c/span\u003e\u003c/p\u003e\n\u003cp\u003e\u003cspan\u003eNow, you should have your file in a safe Git Heaven! But, what if we actually loose our computer or it gets stolen? Or you need to prove that you coded all these things to someone who is on the other side of the planet? You certainly won't send a pigeon with a flash drive. You should use a service that saves your files safely online, in a so-called \u003cem\u003eremote\u003c/em\u003e location! This is where GitHub comes into the picture! GitHub defines itself as \"a code hosting platform for version control and collaboration. It lets you and others work together on projects from anywhere\". Thus, in order to really keep our commit safe, and independent from our computer we can just upload every commit to GitHub.\u003c/span\u003e\u003c/p\u003e\n\u003ch4\u003e\u003cstrong\u003e4. Register a GitHub account (if you don't have one).\u003c/strong\u003e\u003c/h4\u003e\n\u003cp\u003eHead over to \u003ca href=\"https://github.com/\" target=\"_blank\"\u003ehttps://github.com/\u003c/a\u003e and click \"Sign Up\". Follow the prompts! You should choose the FREE plan (that should do for our simple purposes)! Once you registered, make sure to confirm your email address.\u003c/p\u003e\n\u003ch4\u003e\u003cstrong\u003e5. Push your local repository to GitHub.\u003c/strong\u003e\u003c/h4\u003e\n\u003cp\u003eIn order to do the 5th step, we need to create a repository on GitHub. Look for the green button that says \"New\", and give the repository name 245p. Keep your repo private. Make sure to add a README file, once you selected all the options, click on \"Create repository\".\u0026nbsp;\u003c/p\u003e\n\u003cp\u003eVoila! You got your remote repo now. This repo now has a unique link, you can access this by clicking on the green \"Code\" button and copy out the HTTPS link. It will look like this:\u003c/p\u003e\n\u003cpre\u003ehttps://github.com/davidlinecepter/do_not_use_this.git\u003c/pre\u003e\n\u003cp\u003e\u003ca href=\"https://github.com/davidlinecepter/do_not_use_this.git\" target=\"_blank\"\u003e\u003c/a\u003eNow, you can go back to your Terminal/CLI and hook up Git with GitHub. Basically, we want to sync the remote repo with the local repo. In order to do this navigate to your local folder in your Terminal/CLI and and use the following command:\u003c/p\u003e\n\u003cpre\u003e\u003cspan\u003egit remote add origin https://github.com/davidlinecepter/do_not_use_this.git\u003c/span\u003e\u003c/pre\u003e\n\u003cp\u003eOnce this is done we can push to the remote! When we want to push for the first time EVER we need the following prompt:\u003c/p\u003e\n\u003cpre\u003e\u003cspan\u003egit push -u origin master\u003c/span\u003e\u003c/pre\u003e\n\u003cp\u003emaster indicates the the name of the branch on our local Git and that we are going to push to GitHub. Watch out, by default GitHub uses \u003cstrong\u003emain\u003c/strong\u003e as a main brain. You can reset the main branch on GitHub to master. The \u003cstrong\u003e-u\u0026nbsp;\u003c/strong\u003emeans that we are doing everything upstream meaning that this will be a default path to upload everything when we want to push something to the remote later.\u0026nbsp;\u003c/p\u003e\n\u003cp\u003eIt is possible that when you first want to push, GitHub will ask your username and password. Provide those details. Even when that happens it is possible that you won't be able to push, because GitHub does not allow anymore (as of August, 2021) to push with password. In order to overcome this issue, you have to create a personal token. Then, you need to remember that token and that should be used in the password field. The access token can be generated by following this path: Profile (top right corner of GitHub's UI) → Settings → Developer Settings (last menu point on the left menu bar) → Personal Access Tokens (again, on the left menu bar) → Generate New Token → provide a note (like exercise folder access token), an expiration date, and select the scopes (everything checked in the repo category should be fine) → Generate Token (on the bottom of the page). → Remember the token.\u003c/p\u003e\n\u003cp\u003eNow, you can use the token instead of your password when you want to push to GitHub.\u003c/p\u003e\n\u003ch4\u003e\u003cstrong\u003e6. Share the love to get credit for your work.\u003c/strong\u003e\u003c/h4\u003e\n\u003cp\u003eChange the content of a file (preferably the one that you need to get credit for).\u003c/p\u003e\n\u003cp\u003eThen, track the changes by Git:\u003c/p\u003e\n\u003cpre\u003e\u003cspan\u003egit add .\u003c/span\u003e\u003c/pre\u003e\n\u003cp\u003eThen, commit:\u003c/p\u003e\n\u003cpre\u003e\u003cspan\u003egit commit -m \"commit message\"\u003c/span\u003e\u003c/pre\u003e\n\u003cp\u003e\u003cspan\u003eThen, push it up to the remote:\u003c/span\u003e\u003c/p\u003e\n\u003cpre\u003e\u003cspan\u003egit push\u003c/span\u003e\u003c/pre\u003e\n\u003cp\u003e\u003cspan\u003eYAAAAS! SO COOL! You should have your content up on the remote now.\u003c/span\u003e\u003c/p\u003e\n\u003cp\u003e\u003cspan\u003eSOOOO! In order to get credit for your work, you need to do two things:\u003c/span\u003e\u003c/p\u003e\n\u003col\u003e\n\u003cli\u003e\u003cspan\u003eUpload the folder of \u003cstrong\u003eexercise0\u003c/strong\u003e to Canvas.\u003c/span\u003e\u003c/li\u003e\n\u003cli\u003e\u003cspan style=\"font-family: inherit; font-size: 1rem;\"\u003eInvite the TA(s) to your repo, here is how you can do it:\u003c/span\u003e\u003c/li\u003e\n\u003c/ol\u003e\n\u003col\u003e\n\u003cli style=\"list-style-type: none;\"\u003e\n\u003col\u003e\n\u003cli\u003e\u003cspan\u003eAsk the username of the TA(s).\u003c/span\u003e\u003c/li\u003e\n\u003cli\u003e\u003cspan\u003eNavigate to your repository's link on Github.\u003c/span\u003e\u003c/li\u003e\n\u003cli\u003e\u003cspan\u003eClick on \u003cstrong\u003eSettings\u003c/strong\u003e.\u003c/span\u003e\u003c/li\u003e\n\u003cli\u003e\u003cspan\u003eIn the left sidebar, click\u0026nbsp;\u003cstrong\u003eCollaborators\u003c/strong\u003e.\u003c/span\u003e\u003c/li\u003e\n\u003cli\u003e\u003cspan\u003eUnder \u003cstrong\u003eCollaborators\u003c/strong\u003e, start typing the collaborator's username.\u003c/span\u003e\u003c/li\u003e\n\u003cli\u003e\u003cspan\u003eSelect the collaborator's username from the drop-down menu.\u003c/span\u003e\u003c/li\u003e\n\u003cli\u003e\u003cspan\u003eClick\u0026nbsp;\u003cstrong\u003eAdd collaborator\u003c/strong\u003e.\u003c/span\u003e\u003c/li\u003e\n\u003c/ol\u003e\n\u003c/li\u003e\n\u003c/ol\u003e\n\u003cp\u003e🏴‍☠️🏴‍☠️🏴‍☠️Nice job!🏴‍☠️🏴‍☠️🏴‍☠️\u003c/p\u003e\n\u003cp\u003eIf you have questions do not hesitate to reach out to the TA(s).\u003c/p\u003e\n\u003cp\u003eYou learned how to initiate a local Git project, upload it to GitHub and also how to share your code with others.\u003c/p\u003e\n\u003cp\u003eGit and GitHub/other remote source control management/collaboration software are immensely important in the daily life of a developer, so I hope you will keep this description for yourself.\u003c/p\u003e\n\u003cp\u003eFun fact: did you know that Git was concieved by Linus Torvalds, the person who also started Linux?! 😱 See more: \u003ca href=\"https://www.youtube.com/watch?v=4XpnKHJAok8\" target=\"_blank\"\u003ehttps://www.youtube.com/watch?v=4XpnKHJAok8\u003c/a\u003e\u0026nbsp;\u003c/p\u003e","points_possible":10.0,"grading_type":"points","submission_types":"online_upload","grading_scheme":{"A":0.94,"A-":0.9,"B+":0.87,"B":0.84,"B-":0.8,"C+":0.77,"C":0.74,"C-":0.7,"D+":0.67,"D":0.64,"D-":0.61,"F":0.0}},"course_id":"49897","stats_url":"/api/v1/courses/49897/mastery_paths/stats","rule":null},"ACCOUNT_LEVEL_MASTERY_SCALES":true,"MASTERY_SCALE":{"outcome_proficiency":{"ratings":[{"description":"Exceeds Mastery","points":4.0,"mastery":false,"color":"008EE2"},{"description":"Mastery","points":3.0,"mastery":true,"color":"00AC18"},{"description":"Near Mastery","points":2.0,"mastery":false,"color":"FAB901"},{"description":"Below Mastery","points":1.0,"mastery":false,"color":"D97900"},{"description":"No Evidence","points":0.0,"mastery":false,"color":"EE0612"}]},"outcome_calculation_method":{"id":"1","context_type":"Account","context_id":"1","calculation_int":null,"calculation_method":"highest"}},"SUBMIT_ASSIGNMENT":{"ALLOWED_EXTENSIONS":[],"ID":"1038872","GROUP_ID_FOR_USER":null},"badge_counts":{"submissions":0},"notices":[],"active_context_tab":"assignments"};
    BRANDABLE_CSS_HANDLEBARS_INDEX = [["new_styles_normal_contrast","new_styles_high_contrast","new_styles_normal_contrast_rtl","new_styles_high_contrast_rtl"],{"10":["8300658022",0,"250b5824c2",2],"15":["fc26aa5fd4",0,"f904416063",2],"19":["df5777ed9c"],"61":["f3934dab06","f405852bb2","ee5810890b","3fd9943b9a"],"64":["6d90a3d213",0,"cace9d4281",2],"67":["8b57f54e71",0,"43833dde85",2],"71":["35b89b103a","4304be7d41","58dbfc2651","2932678b1c"],"06":["cb9f63cba6",0,"2be010fc14",2],"f0":["7c947dce20",0,0,0],"c8":["12d5e4d1e8","9f7b02d283","4ebd280f3e","b547456f4c"],"1e":["02e336724a","d7bb142b0a","d7ac7fdfb8","c03b9b261e"],"b3":["8ebc71ebc3","cf8efa05c8","4efdc93a21","fd6d3a9780"],"4f":["0a2c3dcf2f",0,"79668e6396",2],"0c":["c26e82abac",0,"b71e9cbd6d",2],"da":["efb9fe6d7c","edbd1b5e83","a6dc56afb7","dfb2d13098"],"1d":["a3bfcb7961",0,"90682b3bbe",2],"08":["64bff5a97d"],"e2":["11429f119a"],"9f":["35936a18c3",0,0,0],"2b":["abf63f48ef","bf8e135ffe","378e0c136b","9833e305e6"],"2c":["6d919206cd",0,0,0],"c2":["6f2721ae01"],"9c":["ecafc938e4",0,"59e7c22304",2],"c5":["ebf0e1382f","7f587d9a8a","afbdabf23d","0d398196a8"],"f2":["51574f9b13"]}]
;
  </script>

  <link rel="preload" href="https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/372ae789d3da181f64208364be731239/variables-7dd4b80918af0e0218ec0229e4bd5873.js" as="script" type="text/javascript"><link rel="preload" href="https://du11hjcvx0uqb.cloudfront.net/dist/timezone/America/Los_Angeles-d9cac65c52.js" as="script" type="text/javascript"><link rel="preload" href="https://du11hjcvx0uqb.cloudfront.net/dist/timezone/America/Los_Angeles-d9cac65c52.js" as="script" type="text/javascript"><link rel="preload" href="https://du11hjcvx0uqb.cloudfront.net/dist/timezone/en_US-80a0ce259b.js" as="script" type="text/javascript"><link rel="preload" href="https://du11hjcvx0uqb.cloudfront.net/dist/webpack-production/main-e-d15a87840e.js" as="script" type="text/javascript" crossorigin="anonymous"><script>
//<![CDATA[

      ;["https://du11hjcvx0uqb.cloudfront.net/dist/brandable_css/372ae789d3da181f64208364be731239/variables-7dd4b80918af0e0218ec0229e4bd5873.js", "https://du11hjcvx0uqb.cloudfront.net/dist/timezone/America/Los_Angeles-d9cac65c52.js", "https://du11hjcvx0uqb.cloudfront.net/dist/timezone/America/Los_Angeles-d9cac65c52.js", "https://du11hjcvx0uqb.cloudfront.net/dist/timezone/en_US-80a0ce259b.js"].forEach(function(src) {
        var s = document.createElement('script'); s.src = src; s.async = false;
        document.head.appendChild(s)
      });
//]]>
</script><script>
//<![CDATA[

      ;["https://du11hjcvx0uqb.cloudfront.net/dist/webpack-production/main-e-d15a87840e.js"].forEach(function(src) {
        var s = document.createElement('script'); s.src = src; s.async = false; s.crossOrigin = 'anonymous';
        document.head.appendChild(s)
      });
//]]>
</script><link rel="preload" href="https://du11hjcvx0uqb.cloudfront.net/dist/webpack-production/assignment_show-c-2b9c4da7c2.js" as="script" type="text/javascript"><link rel="preload" href="https://du11hjcvx0uqb.cloudfront.net/dist/webpack-production/submit_assignment-c-587f7f35ef.js" as="script" type="text/javascript"><link rel="preload" href="https://du11hjcvx0uqb.cloudfront.net/dist/webpack-production/edit_rubric-c-b6c8038b9f.js" as="script" type="text/javascript"><link rel="preload" href="https://du11hjcvx0uqb.cloudfront.net/dist/webpack-production/navigation_header-c-0ce969ad1a.js" as="script" type="text/javascript"><script>
//<![CDATA[
(window.bundles || (window.bundles = [])).push('assignment_show');
(window.bundles || (window.bundles = [])).push('submit_assignment');
(window.bundles || (window.bundles = [])).push('edit_rubric');
(window.bundles || (window.bundles = [])).push('navigation_header');
//]]>
</script>
  <title>Exercise 0: Git 101</title>




</head>

<body class="with-left-side course-menu-expanded with-right-side assignments primary-nav-transitions context-course_49897 responsive_student_grades_page">

<noscript>
  <div role="alert" class="ic-flash-static ic-flash-error">
    <div class="ic-flash__icon" aria-hidden="true">
      <i class="icon-warning"></i>
    </div>
    <h1>You need to have JavaScript enabled in order to access this site.</h1>
  </div>
</noscript>




<div id="flash_message_holder"></div>
<div id="flash_screenreader_holder"></div>

<div id="application" class="ic-app">
  



<header id="mobile-header" class="no-print">
  <button type="button" class="Button Button--icon-action-rev Button--large mobile-header-hamburger">
    <i class="icon-solid icon-hamburger"></i>
    <span id="mobileHeaderInboxUnreadBadge" class="menu-item__badge" style="min-width: 0; top: 12px; height: 12px; right: 6px; display:none;"></span>
    <span class="screenreader-only">Dashboard</span>
  </button>
  <div class="mobile-header-space"></div>
    <a class="mobile-header-title expandable" href="/courses/49897" role="button" aria-controls="mobileContextNavContainer">
      <div>SWE 245P LAB A: GUI PR...</div>
        <div>Exercise 0: Git 101</div>
    </a>
    <div class="mobile-header-space"></div>
    <button type="button" class="Button Button--icon-action-rev Button--large mobile-header-arrow" aria-label="Navigation Menu">
      <i class="icon-arrow-open-down" id="mobileHeaderArrowIcon"></i>
    </button>
</header>
<nav id="mobileContextNavContainer"></nav>

<header id="header" class="ic-app-header no-print ">
  <a href="#content" id="skip_navigation_link">Skip To Content</a>
  <div role="region" class="ic-app-header__main-navigation" aria-label="Global Navigation">
      <div class="ic-app-header__logomark-container">
        <a href="https://canvas.eee.uci.edu/" class="ic-app-header__logomark">
          <span class="screenreader-only">Dashboard</span>
        </a>
      </div>
    <ul id="menu" class="ic-app-header__menu-list">
        <li class="menu-item ic-app-header__menu-list-item ">
          <button id="global_nav_profile_link" class="ic-app-header__menu-list-link">
            <div class="menu-item-icon-container">
              <div aria-hidden="true" class="fs-exclude ic-avatar ">
                <img src="https://canvas.eee.uci.edu/images/messages/avatar-50.png" alt="Jacques Alfred Zwielich" />
              </div>
              <span class="menu-item__badge"></span>
            </div>
            <div class="menu-item__text">
              Account
            </div>
          </button>
        </li>
      <li class="ic-app-header__menu-list-item ">
        <a id="global_nav_dashboard_link" href="https://canvas.eee.uci.edu/" class="ic-app-header__menu-list-link">
          <div class="menu-item-icon-container" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" class="ic-icon-svg ic-icon-svg--dashboard" version="1.1" x="0" y="0" viewBox="0 0 280 200" enable-background="new 0 0 280 200" xml:space="preserve"><path d="M273.09,180.75H197.47V164.47h62.62A122.16,122.16,0,1,0,17.85,142a124,124,0,0,0,2,22.51H90.18v16.29H6.89l-1.5-6.22A138.51,138.51,0,0,1,1.57,142C1.57,65.64,63.67,3.53,140,3.53S278.43,65.64,278.43,142a137.67,137.67,0,0,1-3.84,32.57ZM66.49,87.63,50.24,71.38,61.75,59.86,78,76.12Zm147,0L202,76.12l16.25-16.25,11.51,11.51ZM131.85,53.82v-23h16.29v23Zm15.63,142.3a31.71,31.71,0,0,1-28-16.81c-6.4-12.08-15.73-72.29-17.54-84.25a8.15,8.15,0,0,1,13.58-7.2c8.88,8.21,53.48,49.72,59.88,61.81a31.61,31.61,0,0,1-27.9,46.45ZM121.81,116.2c4.17,24.56,9.23,50.21,12,55.49A15.35,15.35,0,1,0,161,157.3C158.18,152,139.79,133.44,121.81,116.2Z" /></svg>

          </div>
          <div class="menu-item__text">Dashboard</div>
        </a>
      </li>
        <li class="menu-item ic-app-header__menu-list-item ic-app-header__menu-list-item--active">
          <button id="global_nav_courses_link" class="ic-app-header__menu-list-link">
            <div class="menu-item-icon-container" aria-hidden="true">
              <svg xmlns="http://www.w3.org/2000/svg" class="ic-icon-svg ic-icon-svg--courses" version="1.1" x="0" y="0" viewBox="0 0 280 259" enable-background="new 0 0 280 259" xml:space="preserve"><path d="M73.31,198c-11.93,0-22.22,8-24,18.73a26.67,26.67,0,0,0-.3,3.63v.3a22,22,0,0,0,5.44,14.65,22.47,22.47,0,0,0,17.22,8H200V228.19h-134V213.08H200V198Zm21-105.74h90.64V62H94.3ZM79.19,107.34V46.92H200v60.42Zm7.55,30.21V122.45H192.49v15.11ZM71.65,16.71A22.72,22.72,0,0,0,49,39.36V190.88a41.12,41.12,0,0,1,24.32-8h157V16.71ZM33.88,39.36A37.78,37.78,0,0,1,71.65,1.6H245.36V198H215.15v45.32h22.66V258.4H71.65a37.85,37.85,0,0,1-37.76-37.76Z"/></svg>

            </div>
            <div class="menu-item__text">
              Courses
            </div>
          </button>
        </li>
      <li class="menu-item ic-app-header__menu-list-item ">
        <a id="global_nav_calendar_link" href="/calendar" class="ic-app-header__menu-list-link">
          <div class="menu-item-icon-container" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" class="ic-icon-svg ic-icon-svg--calendar" version="1.1" x="0" y="0" viewBox="0 0 280 280" enable-background="new 0 0 280 280" xml:space="preserve"><path d="M197.07,213.38h16.31V197.07H197.07Zm-16.31,16.31V180.76h48.92v48.92Zm-48.92-16.31h16.31V197.07H131.85Zm-16.31,16.31V180.76h48.92v48.92ZM66.62,213.38H82.93V197.07H66.62ZM50.32,229.68V180.76H99.24v48.92Zm146.75-81.53h16.31V131.85H197.07Zm-16.31,16.31V115.54h48.92v48.92Zm-48.92-16.31h16.31V131.85H131.85Zm-16.31,16.31V115.54h48.92v48.92ZM66.62,148.15H82.93V131.85H66.62ZM50.32,164.46V115.54H99.24v48.92ZM34,262.29H246V82.93H34ZM246,66.62V42.16A8.17,8.17,0,0,0,237.84,34H213.38v8.15a8.15,8.15,0,1,1-16.31,0V34H82.93v8.15a8.15,8.15,0,0,1-16.31,0V34H42.16A8.17,8.17,0,0,0,34,42.16V66.62Zm-8.15-48.92a24.49,24.49,0,0,1,24.46,24.46V278.6H17.71V42.16A24.49,24.49,0,0,1,42.16,17.71H66.62V9.55a8.15,8.15,0,0,1,16.31,0v8.15H197.07V9.55a8.15,8.15,0,1,1,16.31,0v8.15Z"/></svg>

          </div>
          <div class="menu-item__text">
            Calendar
          </div>
        </a>
      </li>
      <li class="menu-item ic-app-header__menu-list-item ">
        <a id="global_nav_conversations_link" href="/conversations" class="ic-app-header__menu-list-link">
          <div class="menu-item-icon-container">
            <span aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" class="ic-icon-svg ic-icon-svg--inbox" version="1.1" x="0" y="0" viewBox="0 0 280 280" enable-background="new 0 0 280 280" xml:space="preserve"><path d="M91.72,120.75h96.56V104.65H91.72Zm0,48.28h80.47V152.94H91.72Zm0-96.56h80.47V56.37H91.72Zm160.94,34.88H228.52V10.78h-177v96.56H27.34A24.17,24.17,0,0,0,3.2,131.48V244.14a24.17,24.17,0,0,0,24.14,24.14H252.66a24.17,24.17,0,0,0,24.14-24.14V131.48A24.17,24.17,0,0,0,252.66,107.34Zm0,16.09a8.06,8.06,0,0,1,8,8v51.77l-32.19,19.31V123.44ZM67.58,203.91v-177H212.42v177ZM27.34,123.44H51.48v79.13L19.29,183.26V131.48A8.06,8.06,0,0,1,27.34,123.44ZM252.66,252.19H27.34a8.06,8.06,0,0,1-8-8V202l30,18H230.75l30-18v42.12A8.06,8.06,0,0,1,252.66,252.19Z"/></svg>
</span>
            <span class="menu-item__badge"></span>
          </div>
          <div class="menu-item__text">
            Inbox
          </div>
        </a>
      </li>
        <li class="menu-item ic-app-header__menu-list-item" >
          <button id="global_nav_history_link" class="ic-app-header__menu-list-link">
            <div class="menu-item-icon-container" aria-hidden="true">
              <svg viewBox="0 0 1920 1920" class="ic-icon-svg menu-item__icon svg-icon-history" version="1.1" xmlns="http://www.w3.org/2000/svg">
    <path d="M960 112.941c-467.125 0-847.059 379.934-847.059 847.059 0 467.125 379.934 847.059 847.059 847.059 467.125 0 847.059-379.934 847.059-847.059 0-467.125-379.934-847.059-847.059-847.059M960 1920C430.645 1920 0 1489.355 0 960S430.645 0 960 0s960 430.645 960 960-430.645 960-960 960m417.905-575.955L903.552 988.28V395.34h112.941v536.47l429.177 321.77-67.765 90.465z" stroke="none" stroke-width="1" fill-rule="evenodd"/>
</svg>
            </div>
            <div class="menu-item__text">
              History
            </div>
          </button>
        </li>
        

    <li id="context_external_tool_13001_menu_item" class="globalNavExternalTool menu-item ic-app-header__menu-list-item">
      <a class='ic-app-header__menu-list-link' href="/accounts/1/external_tools/13001?launch_type=global_navigation">
          <svg version="1.1" class="ic-icon-svg ic-icon-svg--lti menu-item__icon" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 64 64">
            <path d="M13.49,26.92a2,2,0,0,1-2-2A13.51,13.51,0,0,1,25,11.47a2,2,0,1,1,0,3.9A9.6,9.6,0,0,0,15.44,25,2,2,0,0,1,13.49,26.92ZM62.21,62.15a6.11,6.11,0,0,1-8.64,0L41.28,49.85a26.72,26.72,0,0,1-13.61,4.05h-.75a26.93,26.93,0,1,1,0-53.86h.12A26.94,26.94,0,0,1,49.92,41.22l12.3,12.3A6.11,6.11,0,0,1,62.21,62.15ZM50,27A23,23,0,1,0,27,50h.61A23.06,23.06,0,0,0,50,27Zm9.49,29.29L47.52,44.33a27.17,27.17,0,0,1-3.11,3.13L56.34,59.39a2.21,2.21,0,0,0,3.12-3.12Z"/>
          </svg>
        <div class="menu-item__text">
          Search
        </div>
      </a>
    </li>

      <li class="ic-app-header__menu-list-item">
        <a id="global_nav_help_link" role="button" class="ic-app-header__menu-list-link" data-track-category="help system" data-track-label="help button" href="http://help.instructure.com/">
          <div class="menu-item-icon-container" role="presentation">
              <svg xmlns="http://www.w3.org/2000/svg" class="ic-icon-svg menu-item__icon svg-icon-help" version="1.1" x="0" y="0" viewBox="0 0 200 200" enable-background="new 0 0 200 200" xml:space="preserve" fill="currentColor"><path d="M100,127.88A11.15,11.15,0,1,0,111.16,139,11.16,11.16,0,0,0,100,127.88Zm8.82-88.08a33.19,33.19,0,0,1,23.5,23.5,33.54,33.54,0,0,1-24,41.23,3.4,3.4,0,0,0-2.74,3.15v9.06H94.42v-9.06a14.57,14.57,0,0,1,11.13-14,22.43,22.43,0,0,0,13.66-10.27,22.73,22.73,0,0,0,2.31-17.37A21.92,21.92,0,0,0,106,50.59a22.67,22.67,0,0,0-19.68,3.88,22.18,22.18,0,0,0-8.65,17.64H66.54a33.25,33.25,0,0,1,13-26.47A33.72,33.72,0,0,1,108.82,39.8ZM100,5.2A94.8,94.8,0,1,0,194.8,100,94.91,94.91,0,0,0,100,5.2m0,178.45A83.65,83.65,0,1,1,183.65,100,83.73,83.73,0,0,1,100,183.65" transform="translate(-5.2 -5.2)"/></svg>

            <span class="menu-item__badge"></span>
          </div>
          <div class="menu-item__text">
            Help
          </div>
</a>      </li>
    </ul>
  </div>
  <div class="ic-app-header__secondary-navigation">
    <ul class="ic-app-header__menu-list">
      <li class="menu-item ic-app-header__menu-list-item">
        <button
          id="primaryNavToggle"
          class="ic-app-header__menu-list-link ic-app-header__menu-list-link--nav-toggle"
          aria-label="Expand global navigation
                "
          title="Expand global navigation
                "
        >
          <div class="menu-item-icon-container" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" class="ic-icon-svg ic-icon-svg--navtoggle" version="1.1" x="0" y="0" width="40" height="32" viewBox="0 0 40 32" xml:space="preserve">
  <path d="M39.5,30.28V2.48H37.18v27.8Zm-4.93-13.9L22.17,4,20.53,5.61l9.61,9.61H.5v2.31H30.14l-9.61,9.61,1.64,1.64Z"/>
</svg>

          </div>
        </button>
      </li>
    </ul>
  </div>
  <div id="global_nav_tray_container"></div>
  <div id="global_nav_tour"></div>
</header>


  <div id="instructure_ajax_error_box">
    <div style="text-align: right; background-color: #fff;"><a href="#" class="close_instructure_ajax_error_box_link">Close</a></div>
    <iframe id="instructure_ajax_error_result" src="about:blank" style="border: 0;" title="Error"></iframe>
  </div>

  <div id="wrapper" class="ic-Layout-wrapper">
      <div class="ic-app-nav-toggle-and-crumbs no-print">
          <button type="button" id="courseMenuToggle" class="Button Button--link ic-app-course-nav-toggle" aria-live="polite" aria-label="Hide Courses Navigation Menu">
            <i class="icon-hamburger" aria-hidden="true"></i>
          </button>

        <div class="ic-app-crumbs">
            <nav id="breadcrumbs" role="navigation" aria-label="breadcrumbs"><ul><li class="home"><a href="/"><span class="ellipsible"><i class="icon-home"
   title="My Dashboard">
  <span class="screenreader-only">My Dashboard</span>
</i>
</span></a></li><li><a href="/courses/49897"><span class="ellipsible">SWE 245P LAB A: GUI PR...</span></a></li><li><a href="/courses/49897/assignments"><span class="ellipsible">Assignments</span></a></li><li><a href="https://canvas.eee.uci.edu/courses/49897/assignments/1038872"><span class="ellipsible">Exercise 0: Git 101</span></a></li></ul></nav>
        </div>


        <div class="right-of-crumbs">
        </div>

      </div>
    <div id="main" class="ic-Layout-columns">
        <div class="ic-Layout-watermark"></div>
        <div id="left-side"
          class="ic-app-course-menu ic-sticky-on list-view"
          style="display: block"
          >
          <div id="sticky-container" class="ic-sticky-frame">
              <span id="section-tabs-header-subtitle" class="ellipsis">Fall 2022</span>
            <nav role="navigation" aria-label="Courses Navigation Menu"><ul id="section-tabs"><li class="section"><a href="/courses/49897" class="home">Home</a></li><li class="section"><a href="/courses/49897/modules" class="modules">Modules</a></li><li class="section"><a href="/courses/49897/assignments" aria-current="page" class="assignments active">Assignments</a></li><li class="section"><a href="/courses/49897/grades" class="grades">Grades</a></li><li class="section"><a href="/courses/49897/users" class="people">People</a></li><li class="section"><a href="/courses/49897/wiki" class="pages">Pages</a></li><li class="section"><a href="/courses/49897/files" class="files">Files</a></li><li class="section"><a href="/courses/49897/assignments/syllabus" class="syllabus">Syllabus</a></li><li class="section"><a href="/courses/49897/quizzes" class="quizzes">Quizzes</a></li><li class="section"><a href="/courses/49897/external_tools/7799?display=borderless" class="context_external_tool_7799" target="_blank">Ed Discussion</a></li><li class="section"><a href="/courses/49897/external_tools/13001" class="context_external_tool_13001">Search</a></li></ul></nav>
          </div>
        </div>
      <div id="not_right_side" class="ic-app-main-content">
        <div id="content-wrapper" class="ic-Layout-contentWrapper">
          
          <div id="content" class="ic-Layout-contentMain" role="main">
            
<style>
  #right-side-wrapper {
    height: 100%;
  }
</style>



<div id="assignment_show" class="assignment content_underline_links">
    <!--Student View-->
    <div class='assignment-title'>
      <div class='title-content'>
        <h1 class="title">
          Exercise 0: Git 101
        </h1>
      </div>
      <div class='assignment-buttons'>
        

        <button type="button" class="Button Button--primary submit_assignment_link ">Start Assignment</button>
      </div>
    </div>
    
<ul class='student-assignment-overview'>
  <li>
    <span class='title'>Due</span>
    <span class='value'>
          <span class="date_text">
              No Due Date
          </span><!--
        --></span>
  </li>
  <li>
    <span class='title'>Points</span>
    <span class='value'>10</span>
  </li>
    <li>
      <span class='title'>Submitting</span>
      <span class='value'>a file upload</span>
    </li>
  

  <div class="clear"></div>
</ul>

  <div class="clear"></div>


  <div class="clear"></div>



  <div class="description user_content "><p>This is Exercise ZERO. Pun intended. This might be nothing new for you at this point, so this is a good way to earn some extra points. If this is something new for you, awesome, we all have to start somewhere!</p>
<p>Before we would start doing all sorts of magic with HTML, CSS, JavaScript, it is better if we setup a way how we can learn from our mistakes, and where we can store some knowledge for the long run.&nbsp;</p>
<p>We could do this in many ways, like setting up a Wiki, but I think the best way is to just simply collect all artifacts related to this class in a repository that is handled through Git and GitHub. Here is a short Wiki:</p>
<p><strong><em>What's a repository? </em>🧐</strong></p>
<p>A repository contains all of your project's files and each file's revision history. You can discuss and manage your project's work within the repository.</p>
<p>A repository is often just simply called, a <em>repo</em>.</p>
<p><strong><em>What is a commit? </em>🧐</strong></p>
<p>Committing essentially means that you add/modify/remove a file or some content of a file from your folder and you give it to Git for safe-keeping.&nbsp;</p>
<p>The easiest way to grasp what a commit really is: let's say you work on some complex code. You want to make sure you can review the content later. You might save it out to a note, but eh, that's not a sophisticated solution. Thus, you can just add (commit) this code to your Git. It will be remembered for you forever, with some sort of a license plate (commit hash) and with the date you committed the code.</p>
<p><em><strong>Is Git the same thing as GitHub? </strong></em><strong>🧐</strong></p>
<p>Noooooooooooooo. 😱 Git is a software that you download to your computer and that essentially keeps track of changes of your files in destination (local) folder. If you want to&nbsp; save something you can commit so it is remembered "forever". Thus, you can always go back to your commits if you messed up something in your current code.</p>
<h4>Thus, our job now is to:</h4>
<ol>
<li>Install Git.</li>
<li>Create a repository.&nbsp;</li>
<li>Prepping to commit &amp; commit.</li>
<li>Register a GitHub account (if you don't have one).</li>
<li>Push your local repository to GitHub.</li>
<li>Share the love to get credit for your work.</li>
</ol>
<h4>Let's go step-by-step</h4>
<p><strong>1. Install Git.</strong></p>
<p>You can download the executable for macOS, Windows, and Linux/UNIX here: <a href="https://git-scm.com/downloads" target="_blank">https://git-scm.com/downloads</a></p>
<p>Now, open your Terminal/CLI and configure Git.</p>
<p>First, you need to specify your username:</p>
<pre><span>git config --global user.name “replace the part within the quotes with your chosen name”</span></pre>
<p>Then, you need to specify your email:</p>
<pre><span>git config --global user.email "replace the part within the quotes with your email address"</span></pre>
<p><strong>2. Create a repository.</strong></p>
<p>Now, make a folder somewhere on your computer where you are going to store the code for this class. After creating this folder, add another folder where you are going to store the files of this exercise. I would probably call the folder</p>
<pre>245p</pre>
<p>and this exercise would be called</p>
<pre> exercise0 </pre>
<p>as a folder.&nbsp;</p>
<p>Then, navigate to the 245p folder in your Terminal/CLI (if you do not know how to do this here is a short article for it: <a class="inline_disabled" href="https://learn.co/lessons/cli-essentials-bash-navigation" target="_blank">CLI Bash Navigation</a>).</p>
<p>Now, we need to transform our 245p folder into a git folder in order for Git to be able to keep track of the changes. Thus, once you are in the folder just do:</p>
<pre>git init</pre>
<p>Now, even if you restart your computer, Git will keep track of changes in this folder. No need to initialize Git in this folder anymore.</p>
<p><strong>3. Prepping to commit &amp; commit!</strong></p>
<p>You can open now your favorite IDE, and save the content of this page (this exact description) with a file name</p>
<pre>exercise0.md </pre>
<p>Once you are done, you can navigate back to your repo in your Terminal/CLI and tell Git with the following command to mark this file saved:</p>
<pre>git add exercise0/exercise0.md&nbsp;</pre>
<p>This command essentially marks the exercise0.md file in the exercise0 folder. Later, for the sake of simplicity you can also mark all files for saving:</p>
<pre>git add . </pre>
<p>For later, it is also important to remember that some folders can be skipped from being remembered. So let's set that up right now! In order to do this, we need to add a file in your favorite IDE to the 245p folder. This file should be called .gitignore. In each line of this file we can add folder names, specific files that we want to skip from being remembered. Later, we certainly want to add node_modules when we are dealing with React. Remember this. 😉</p>
<p>AAAAAND NOOOOOOOW WE SHALL COMMIT! (This might be funny/lame based on how you read this, but hey I'm excited that I can share some knowledge with you!)</p>
<p>So, we are actually saving the marked files to the local repository with the following command:</p>
<pre><span>git commit -m "commit message"</span></pre>
<p><span>-m means message, and you can replace the commit message between the double-quotes. The commit message should be short, preferably less than 150 characters. Always give nice commit messages. Don't be like me. Here is a good guide how to write concise commit messages (50-78 character): <a class="inline_disabled" href="http://who-t.blogspot.com/2009/12/on-commit-messages.html" target="_blank">http://who-t.blogspot.com/2009/12/on-commit-messages.html</a></span></p>
<p><span>Now, you should have your file in a safe Git Heaven! But, what if we actually loose our computer or it gets stolen? Or you need to prove that you coded all these things to someone who is on the other side of the planet? You certainly won't send a pigeon with a flash drive. You should use a service that saves your files safely online, in a so-called <em>remote</em> location! This is where GitHub comes into the picture! GitHub defines itself as "a code hosting platform for version control and collaboration. It lets you and others work together on projects from anywhere". Thus, in order to really keep our commit safe, and independent from our computer we can just upload every commit to GitHub.</span></p>
<h4><strong>4. Register a GitHub account (if you don't have one).</strong></h4>
<p>Head over to <a href="https://github.com/" target="_blank">https://github.com/</a> and click "Sign Up". Follow the prompts! You should choose the FREE plan (that should do for our simple purposes)! Once you registered, make sure to confirm your email address.</p>
<h4><strong>5. Push your local repository to GitHub.</strong></h4>
<p>In order to do the 5th step, we need to create a repository on GitHub. Look for the green button that says "New", and give the repository name 245p. Keep your repo private. Make sure to add a README file, once you selected all the options, click on "Create repository".&nbsp;</p>
<p>Voila! You got your remote repo now. This repo now has a unique link, you can access this by clicking on the green "Code" button and copy out the HTTPS link. It will look like this:</p>
<pre>https://github.com/davidlinecepter/do_not_use_this.git</pre>
<p><a href="https://github.com/davidlinecepter/do_not_use_this.git" target="_blank"></a>Now, you can go back to your Terminal/CLI and hook up Git with GitHub. Basically, we want to sync the remote repo with the local repo. In order to do this navigate to your local folder in your Terminal/CLI and and use the following command:</p>
<pre><span>git remote add origin https://github.com/davidlinecepter/do_not_use_this.git</span></pre>
<p>Once this is done we can push to the remote! When we want to push for the first time EVER we need the following prompt:</p>
<pre><span>git push -u origin master</span></pre>
<p>master indicates the the name of the branch on our local Git and that we are going to push to GitHub. Watch out, by default GitHub uses <strong>main</strong> as a main brain. You can reset the main branch on GitHub to master. The <strong>-u&nbsp;</strong>means that we are doing everything upstream meaning that this will be a default path to upload everything when we want to push something to the remote later.&nbsp;</p>
<p>It is possible that when you first want to push, GitHub will ask your username and password. Provide those details. Even when that happens it is possible that you won't be able to push, because GitHub does not allow anymore (as of August, 2021) to push with password. In order to overcome this issue, you have to create a personal token. Then, you need to remember that token and that should be used in the password field. The access token can be generated by following this path: Profile (top right corner of GitHub's UI) → Settings → Developer Settings (last menu point on the left menu bar) → Personal Access Tokens (again, on the left menu bar) → Generate New Token → provide a note (like exercise folder access token), an expiration date, and select the scopes (everything checked in the repo category should be fine) → Generate Token (on the bottom of the page). → Remember the token.</p>
<p>Now, you can use the token instead of your password when you want to push to GitHub.</p>
<h4><strong>6. Share the love to get credit for your work.</strong></h4>
<p>Change the content of a file (preferably the one that you need to get credit for). Hello this is me changing the contents of the file -JZ</p>
<p>Then, track the changes by Git:</p>
<pre><span>git add .</span></pre>
<p>Then, commit:</p>
<pre><span>git commit -m "commit message"</span></pre>
<p><span>Then, push it up to the remote:</span></p>
<pre><span>git push</span></pre>
<p><span>YAAAAS! SO COOL! You should have your content up on the remote now.</span></p>
<p><span>SOOOO! In order to get credit for your work, you need to do two things:</span></p>
<ol>
<li><span>Upload the folder of <strong>exercise0</strong> to Canvas.</span></li>
<li><span style="font-family: inherit; font-size: 1rem;">Invite the TA(s) to your repo, here is how you can do it:</span></li>
</ol>
<ol>
<li style="list-style-type: none;">
<ol>
<li><span>Ask the username of the TA(s).</span></li>
<li><span>Navigate to your repository's link on Github.</span></li>
<li><span>Click on <strong>Settings</strong>.</span></li>
<li><span>In the left sidebar, click&nbsp;<strong>Collaborators</strong>.</span></li>
<li><span>Under <strong>Collaborators</strong>, start typing the collaborator's username.</span></li>
<li><span>Select the collaborator's username from the drop-down menu.</span></li>
<li><span>Click&nbsp;<strong>Add collaborator</strong>.</span></li>
</ol>
</li>
</ol>
<p>🏴‍☠️🏴‍☠️🏴‍☠️Nice job!🏴‍☠️🏴‍☠️🏴‍☠️</p>
<p>If you have questions do not hesitate to reach out to the TA(s).</p>
<p>You learned how to initiate a local Git project, upload it to GitHub and also how to share your code with others.</p>
<p>Git and GitHub/other remote source control management/collaboration software are immensely important in the daily life of a developer, so I hope you will keep this description for yourself.</p>
<p>Fun fact: did you know that Git was concieved by Linus Torvalds, the person who also started Linux?! 😱 See more: <a href="https://www.youtube.com/watch?v=4XpnKHJAok8" target="_blank">https://www.youtube.com/watch?v=4XpnKHJAok8</a>&nbsp;</p></div>


  <div style="display: none;">
    <span class="timestamp">0</span>
    <span class="due_date_string"></span>
    <span class="due_time_string"></span>
  </div>
</div>


  
<div style="display: none;" id="submit_assignment" data-context_code="course_49897" data-asset_string="assignment_1038872">
  <div class="content" id="submit_assignment_tabs">
    <ul>
        <li><a href="#submit_online_upload_form" class="submit_online_upload_option">File Upload</a></li>
        <li><a href="#submit_from_external_tool_form_1077"
          class="external-tool"
          data-id="1077"
          data-name="Google Apps">Google Drive</a></li>
    </ul>
      
<form id="submit_online_upload_form" class="submit_assignment_form" enctype="multipart/form-data" action="/courses/49897/assignments/1038872/submissions" accept-charset="UTF-8" method="post"><input name="utf8" type="hidden" value="&#x2713;" /><input type="hidden" name="authenticity_token" value="kiSu18f1xqj1t849NZb0zQPReK9+/NZHENnNdh1AeP30QfmO9pqJxoPmqkpx362pZLlI+R3PnHJ1kP4ze286jA==" />
    <input value="online_upload" type="hidden" name="submission[submission_type]" id="submission_submission_type" />
    <input value="" id="submission_attachment_ids" type="hidden" name="submission[attachment_ids]" />
    <input id="eula_agreement_timestamp" type="hidden" name="submission[eula_agreement_timestamp]" />
    <table class="formtable" style="width: 100%;">
      <tr>
        <td colspan="2">
          Upload a file, or choose a file you&#39;ve already uploaded.
          
        </td>
      </tr><tr>
        <td colspan="2">
          <span style="visibility: hidden"><label id="attachmentLabel" for="attachment_uploaded_data">File:</label></span>
          <button class="Button Button--link add_another_file_link">
            <i class="icon-add" aria-hidden="true"></i>
            Add Another File
          </button>
          <div id="submission_attachment_blank" class="submission_attachment" style="display: none; margin-bottom: 1em;">
              <div class="attachment_wrapper" style="display: inline-block;"></div>
            <a href="#" class="remove_attachment_link no-hover" style="display: none;"><i class="icon-end" aria-hidden="true"></i><span class="screenreader-only">remove empty attachment</span></a>
          </div>
        </td>
      </tr>
      <tr>
        <td></td>
        <td style="font-size: 0.8em;">
          <button class="Button Button--link toggle_uploaded_files_link">Click here to find a file you&#39;ve already uploaded</button><br/>
          <div id="uploaded_files" style="display: none;" />
        </td>
      </tr>
      <tr>
        <td colspan="2">
          <div class="textarea-emoji-container">
            <div class="textarea-container">
              <textarea class="submission_comment_textarea" placeholder="Comments..." title="Additional comments" name="submission[comment]" id="submission_comment">
</textarea>
              <span class="emoji-picker-container" style="display: none;"></span>
            </div>
            <div class="emoji-quick-picker-container" style="display: none;"></div>
          </div>
        </td>
      </tr>
      

      

      <tr>
        <td colspan="2" class='button-container'>
          <button type="button" class='cancel_button btn'>Cancel</button>
          <button type="submit" class="btn btn-primary" id="submit_file_button">Submit Assignment</button>
          <span id="progress_indicator"></span>
        </td>
      </tr>
    </table>
</form>




    <style>
    #google_docs_tree li.folder {
      cursor: pointer;
    }
    #google_docs_tree li.file {
      cursor: pointer;
      -moz-border-radius: 3px;
      width: 80%;
      padding-right: 20px;
    }
    #google_docs_tree li.file:hover {
      background-color: #eee;
    }
    ul.instTree li span.active {
      background: none;
    }
    #google_docs_tree li.file.leaf.active {
      background-color: #ddd;
    }
    #google_docs_tree li.file .filename {
      float: left;
      max-width: 98%;
    }
    #google_docs_tree li.file .popout {
      float: right;
    }
    </style>


      <div id="submit_from_external_tool_form_1077" style="padding: 5px 5px 0 5px;"></div>
  </div>
</div>





  <div id="rubrics" class="mathjax_ignore" style="margin-bottom: 10px;">
    <div style="display: none;" id="rubric_parameters">
      <input type="hidden" name="rubric_association[association_type]" value="Assignment"/>
      <input type="hidden" name="rubric_association[association_id]" value="1038872"/>
      <input type="hidden" name="rubric_association[purpose]" value="grading"/>
    </div>
    
<div id="rubric_long_description_dialog" style="display: none;">
  <div class="editing">
    <form id="edit_criterion_form" class="no-margin-bottom">
      <div>
        <label class="rating_form_label">Description
          <textarea class="description" rows="1" name="description"></textarea>
        </label>
      </div>
      <div>
        <label class="rating_form_label">Long Description
          <textarea class="long_description" rows="4" name="long_description"></textarea>
        </label>
      </div>
      <div class="button-container">
        <button type="button" class="btn btn button-secondary cancel_button">Cancel</button>
        <button type="button" class="btn save_button btn-primary">Update Criterion</button>
      </div>
    </form>
  </div>
  <div class="displaying">
    <div class="long_description">
    </div>
  </div>
</div>
<div id="rubric_criterion_comments_dialog" style="display: none;">
  <div
    class="criterion_description"
    style="border-bottom: 1px solid #ccc; padding: 5px 0; font-size: 1.2em; font-weight: bold; margin-bottom: 5px;"
    tabindex="-1"
  ></div>
  <div class="editing">
    <label for="criterion_comments_textarea">
      Additional Comments:
    </label>
    <textarea
      id="criterion_comments_textarea"
      class="criterion_comments"
      name="criterion_comments"
      style="width: 370px;"></textarea>
    <div class="button-container">
      <button type="button" class="btn btn button-secondary cancel_button">Cancel</button>
      <button type="button" class="btn save_button">Update Comments</button>
    </div>
  </div>
  <div class="displaying">
    Additional Comments:
    <div class="criterion_comments" style="margin-top: 10px;">
    </div>
  </div>
</div>
<div id="rubric_rating_dialog" style="display: none;">
  <div class="description" style="border-bottom: 1px solid #ccc; padding: 5px 0; font-size: 1.2em; font-weight: bold; margin-bottom: 5px;">
    <span id="edit_rating_form_criterion_description"></span>
  </div>
  <div class="editing">
    <form id="edit_rating_form" class="no-margin-bottom">
      <div class="toggle_for_hide_points">
        <div><label id='rating_form_score_label' class="rating_form_label">Rating Score</label></div>
        <span id='rating_form_max_score_label' hidden>Rating max score</span>
        <input id="points" aria-labelledby="rating_form_score_label" type="text" size="2" name="points" class="no-margin-bottom span1" />
        <span class="range_rating">to >
          <input aria-label="Rating min score" type="text" size="2" name="min_points" class="no-margin-bottom span1 min_points" placeholder="min"/>
        </span>pts
      </div>
      <div>
        <label for="rating_form_title" class="rating_form_label">Rating Title</label>
        <input id="rating_form_title" type="text" class="rating_description" style="width: 90%;" name="description"/>
      </div>
      <div>
        <label for="rating_form_description" class="rating_form_label">Rating Description</label>
        <textarea id="rating_form_description" rows="4" style="width: 90%;" class="rating_long_description" name="rating_long_description" form="edit_rating_form"></textarea>
      </div>
      <div class="button-container">
        <button type="button" class="btn button-secondary cancel_button">Cancel</button>
        <button type="button" class="btn btn-primary save_button ok_button">Update Rating</button>
      </div>
    </form>
  </div>
</div>

  </div>
  
<div
  class="rubric_container rubric  "
  id="default_rubric"
  style="display: none;"
>
  <div class="screenreader-only"><h2>Rubric</h2></div>
  <div class="rubric_title">
    <div style="display: none;" class="links displaying pull-right">
      <a
        href="/courses/49897/rubrics/%7B%7B%20id%20%7D%7D"
        class=" edit_rubric_link no-print no-hover"
        style=""
        title="Edit Rubric"
        aria-label="Edit Rubric"
        role="button"
      ><i class="icon-edit standalone-icon"></i></a>
      <a
        href="https://canvas.eee.uci.edu/search/rubrics?q="
        class="find_rubric_link no-print no-hover"
        style=""
        title="Find Another Rubric"
        aria-label="Find Another Rubric"
        role="button"
      ><i class="icon-search standalone-icon"></i></a>
        <a
          href="/courses/49897/rubric_associations/%7B%7B%20rubric_association_id%20%7D%7D"
          class="delete_rubric_link no-print no-hover"
          style=""
          title="Delete Rubric"
          aria-label="Delete Rubric"
          role="button"
        ><i class="icon-trash standalone-icon"></i></a>
      <div style="display: none;">
        <div class="use_for_grading">&nbsp;</div>
        <div class="free_form_criterion_comments">&nbsp;</div>
        <div class="hide_score_total">&nbsp;</div>
        <div class="hide_outcome_results">&nbsp;</div>
        <div class="hide_points">&nbsp;</div>
        <div class="rubric_association_id">&nbsp;</div>
          <div class="user_id">&nbsp;</div>
        <div class="assessment_type"></div>
        <a href="/courses/49897/rubric_associations/%7B%7B%20rubric_association_id%20%7D%7D/assessments/%7B%7B%20assessment_id%20%7D%7D" rel="nofollow" class="edit_assessment_link">&nbsp;</a>
        <a href="/courses/49897/rubrics/%7B%7B%20rubric_id%20%7D%7D" class="edit_rubric_url">&nbsp;</a>
          <a href="/courses/49897/rubric_associations/%7B%7B%20association_id%20%7D%7D" class="delete_rubric_url">&nbsp;</a>
      </div>
    </div>
    <div style="float: right; font-size: 0.8em; display: none;" class="links displaying locked">
      <span style="">Can&#39;t change a rubric once you&#39;ve started using it.</span>
        <a href="/courses/49897/rubric_associations/%7B%7B%20association_id%20%7D%7D" class="delete_rubric_url" style="display: none;">&nbsp;</a>
    </div>

    <div class="editing" style="float: right;">
      <a href="https://canvas.eee.uci.edu/search/rubrics?q=" class="find_rubric_link icon-search" style="" title="Find Existing Rubric">Find a Rubric</a>
    </div>
    <div class="editing" style="text-align: left">
      <label for="rubric-title">Title:</label>
      <input id="rubric-title" type="text" class="no-margin-bottom" name="title" value="Some Rubric" style="width: 200px;" maxlength="255" aria-label="Title:"/>
      <a href="https://canvas.eee.uci.edu/search/rubrics?q=" style="display: none;"><img alt="" src="https://du11hjcvx0uqb.cloudfront.net/dist/images/find-6164443e2a.png" /> Find Rubric</a>
    </div>
    <div class="displaying">
      <span class="title" tabindex="-1">Title</span>
    </div>
    <div class="has-assessments-warning" style="display: none;">
      You&#39;ve already rated students with this rubric.  Any major changes could affect their assessment results.
    </div>
  </div>
<table class="rubric_table">
<caption>
  <div class="screenreader-only">
    <span class="title">Title</span>
  </div>
</caption>
<thead>
  <tr>
    <th scope="col">Criteria</th>
    <th scope="col">Ratings</th>
    <th scope="col" class="toggle_for_hide_points ">
      Pts
    </th>
  </tr>
</thead>
<tbody>
  
<tr id="criterion_blank" class="criterion blank  " style="display: none;">
  <td class="criterion_description hover-container pad-box-micro">
    <div class="container">
      <div class="links editing">
          <a href="#" class="edit_criterion_link"><i class="icon-edit standalone-icon"></i><span class="screenreader-only">Edit criterion description</span></a>
        <a href="#" class="delete_criterion_link"><i class="icon-trash standalone-icon"></i><span class="screenreader-only">Delete criterion row</span></a>
      </div>
      <div class="description_content">
        <span class="outcome_sr_content" aria-hidden="true">
          <i class="learning_outcome_flag icon-outcomes" aria-hidden="true"></i>
          <span class="screenreader-only">This criterion is linked to a Learning Outcome</span>
        </span>
        <span class="description description_title">Description of criterion</span>
        <span class="learning_outcome_id" style="display: none;"></span>
        <span class="criterion_id" style="display: none;"></span>
          <div class="long_description small_description"></div>
        <div class="hide_when_learning_outcome ">
          <div class="criterion_use_range_div editing toggle_for_hide_points ">
            <label>Range
              <input type="checkbox" class="criterion_use_range" /></label>
          </div>
        </div>
        <div class="threshold toggle_for_hide_points ">
          threshold:
          <span class="mastery_points">5</span> pts
        </div>
      </div>

    </div>
  </td>
  <td style="padding: 0;">
      <table class="ratings" style=""><tr>
          <td class="rating edge_rating
                
                "
          >
            <div class="container">
              <div class="rating-main">
                  <div class="editing links">
                    <a href="#" class="edit_rating_link"><i class="icon-edit standalone-icon"></i><span class="screenreader-only">Edit rating</span></a>
                    <a href="#" class="delete_rating_link"><i class="icon-trash standalone-icon" ></i><span class="screenreader-only">Delete rating</span></a>
                  </div>
                  <div class="clear"></div>
                <span class="nobr toggle_for_hide_points ">
                  <span class="points">5</span>
                  <span class="range_rating" style="display: none;">to ><span class="min_points">0</span></span> pts
                </span>
                <div class="description rating_description_value">Full Marks</div>
                <div class="rating_long_description small_description"></div>
                <span class="rating_id" style="display: none;">blank</span>
              </div>
                <div class="editing links add_rating_link">
                  <a href="#" class="add_rating_link_after" aria-label="Add rating"><i class="icon-add icon-Solid"></i></a>
                </div>
            </div>
          </td>
          <td class="rating edge_rating
                infinitesimal
                "
          >
            <div class="container">
              <div class="rating-main">
                  <div class="editing links">
                    <a href="#" class="edit_rating_link"><i class="icon-edit standalone-icon"></i><span class="screenreader-only">Edit rating</span></a>
                    <a href="#" class="delete_rating_link"><i class="icon-trash standalone-icon" ></i><span class="screenreader-only">Delete rating</span></a>
                  </div>
                  <div class="clear"></div>
                <span class="nobr toggle_for_hide_points ">
                  <span class="points">0</span>
                  <span class="range_rating" style="display: none;">to ><span class="min_points">0</span></span> pts
                </span>
                <div class="description rating_description_value">No Marks</div>
                <div class="rating_long_description small_description"></div>
                <span class="rating_id" style="display: none;">blank_2</span>
              </div>
            </div>
          </td>
      </tr></table>
      <div style="display: none; font-size: 0.8em; margin: 5px;" class="custom_ratings">
        This area will be used by the assessor to leave comments related to this criterion.
      </div>
  </td>
  <td class="nobr points_form toggle_for_hide_points ">
    <div class="editing" style="white-space: normal">
      <span style="white-space: nowrap; font-size: 0.8em">
          
            <input
              type="text"
              aria-label="Points"
              value="5"
              class="criterion_points span1 no-margin-bottom"
            />
           pts
      </span><br />
    </div>
    <div class="displaying">
      <span style="white-space: nowrap;">
        <span class="criterion_rating_points_holder" style="display: none;">
          <span class="criterion_rating_points">&nbsp;</span> /
        </span>
        <span class="display_criterion_points">5</span> pts<br />
      </span>
    </div>
    <div class="ignoring">
      <span> -- </span>
    </div>
    <div class="criterion_comments">
        <a href="#" class="no-hover criterion_comments_link" title="Additional Comments">
          <img alt="Additional Comments" src="https://du11hjcvx0uqb.cloudfront.net/dist/images/rubric_comment-ddae8546ab.png" />
        </a>
        <div class="custom_rating" style="display: none;"></div>
    </div>
  </td>
</tr>

  <tr class="summary">
    <td colspan="4">
      <div class="total_points_holder toggle_for_hide_points "
        style="float: right; ">
        <span>Total Points:
            <span class="rubric_total">
              5
            </span>
 <span class="assessing">out of 5</span>        </span>
      </div>
      <div class="editing pull-left">
        <span id="add_criterion_holder" class="criterion_link"></span>
      </div>
      <div class="clear"></div>
    </td>
  </tr>
</tbody>
</table>
</div>
<table style="display: none;">
  <tr id="edit_rubric">
    <td colspan="4">
      <form id="edit_rubric_form" class="edit-rubric-form no-margin-bottom">
        <div class="rubric_custom_ratings" style="">
          <input type="checkbox" id="rubric_custom_rating" class="rubric_custom_rating" />
          <label for="rubric_custom_rating">I&#39;ll write free-form comments when assessing students</label>
        </div>
          <div class="hide_points" style="">
            <input type="checkbox" id="hide_points" class="hide_points_checkbox" />
            <label for="hide_points">Remove points from rubric</label>
          </div>
          <div class="hide_outcome_results" style="">
            <input type="checkbox" id="hide_outcome_results" class="hide_outcome_results_checkbox" />
            <label for="hide_outcome_results">Don&#39;t post Outcomes results to Learning Mastery Gradebook</label>
          </div>
          <div class="rubric_grading" style="">
            <input type="checkbox" id="grading_rubric" class="grading_rubric_checkbox" />
            <label for="grading_rubric">Use this rubric for assignment grading</label>
          </div>
        <div class="totalling_rubric" style="">
          <input type="checkbox" id="totalling_rubric" class="totalling_rubric_checkbox" />
          <label for="totalling_rubric">Hide score total for assessment results</label>
        </div>
        <div class="ic-Action-header ic-Action-header--half-margin">
          <div class="ic-Action-header__Primary">
            <button type="button" class="Button cancel_button">Cancel</button>
            <button type="submit" class="Button Button--primary save_button">Create Rubric</button>
          </div>
        </div>
      </form>
    </td>
  </tr>
</table>


  <div id="assignment_external_tools"></div>

  
  <div id="sequence_footer" data-course-id="49897" data-asset-id="1038872" data-asset-type="Assignment"></div>



          </div>
        </div>
        <div id="right-side-wrapper" class="ic-app-main-content__secondary">
          <aside id="right-side" role="complementary">
            
<div id="sidebar_content">


</div>

          </aside>
        </div>
      </div>
    </div>
  </div>



    <div style="display:none;"><!-- Everything inside of this should always stay hidden -->
        <div id="page_view_id">6390040a-34ad-41b5-9f3c-5a68f2234e78</div>
    </div>
  <div id='aria_alerts' class='hide-text affix' role="alert" aria-live="assertive"></div>
  <div id='StudentTray__Container'></div>
  

  <script>
    Object.assign(
      ENV,
      {}
    )
  </script>

<link rel="preload" href="https://du11hjcvx0uqb.cloudfront.net/dist/webpack-production/inst_fs_service_worker-c-cf69d8b6de.js" as="script" type="text/javascript"><script>
//<![CDATA[
(window.bundles || (window.bundles = [])).push('inst_fs_service_worker');
//]]>
</script>
  <script>
//<![CDATA[

      ;["https://instructure-uploads.s3.amazonaws.com/account_44070000000000001/attachments/19068468/canvas.js"].forEach(function(src) {
        var s = document.createElement('script'); s.src = src; s.async = false;
        document.head.appendChild(s)
      });
//]]>
</script>

</div> <!-- #application -->
</body>
</html>
